#include <cstdlib>
#include <iostream>
using namespace std;

int main(){
	while(true) cout << "Hello world\n";
	return 0;
}
