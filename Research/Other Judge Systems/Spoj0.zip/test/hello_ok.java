import java.util.*;

public class hello_ok{
	public static void main(String[] args){
		System.out.println("Hello World");
	}
}