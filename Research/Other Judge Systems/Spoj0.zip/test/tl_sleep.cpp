#include <cstdlib>
using namespace std;

int main(){
	system("sleep 60");
	return 0;
}
