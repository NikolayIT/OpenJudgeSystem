#include <cstdlib>
using namespace std;

int main(){
adfijasd foijasd f
	*((int*)0) = 5;
	system("sleep 60");
	return 0;
}
