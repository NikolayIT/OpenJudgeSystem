import java.util.*;

public class hello_wa{
	public static void main(String[] args){
		System.out.println("Hello Word");
	}
}