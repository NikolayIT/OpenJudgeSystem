import java.util.*;

public class hello_re{
	public static void main(String[] args){
		System.out.println("Hello World");
		throw new Error("Bad!");
	}
}