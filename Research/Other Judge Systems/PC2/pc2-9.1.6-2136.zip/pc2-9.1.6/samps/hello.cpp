
//
// File:    hello.cpp
// Purpose: prints hello world
// Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
//
// $Id: hello.cpp 1632 2008-11-05 03:11:35Z laned $
//

#include <iostream>
using namespace std;

main()
{
	cout << "Hello World.\n";
}

// eof 
