/*
 * File:    hello.c 
 * Purpose: prints: Hello World.
 * Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
 *
 * $Id: hello.c 1631 2008-11-05 03:03:12Z laned $
 *
 */

#include <stdio.h>

main()
{
        printf("Hello World.\n");
        
        exit(0);
}

/* eof */
