
//
// File:    NoOutput.java
// Purpose: exits with no output
// Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
// Oct 13 1998
//
// $Id: NoOutput.java 1683 2008-11-29 22:35:30Z boudreat $
//

public class NoOutput {
    public static void main(String[] args) 
    {
    }
}

// eof
